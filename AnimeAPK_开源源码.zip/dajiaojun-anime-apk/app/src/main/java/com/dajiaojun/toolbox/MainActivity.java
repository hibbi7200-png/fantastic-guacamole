package com.dajiaojun.toolbox;

import android.app.Activity;
import android.os.Bundle;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private LinearLayout content;

    private final int BG = Color.rgb(16, 19, 34);
    private final int CARD = Color.rgb(24, 32, 58);
    private final int TEXT = Color.rgb(247, 250, 255);
    private final int SUB = Color.rgb(170, 182, 211);
    private final int BLUE = Color.rgb(66, 200, 255);
    private final int PURPLE = Color.rgb(176, 132, 255);
    private final int WARN = Color.rgb(255, 204, 102);

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        showHome();
    }

    private void base(String title, String subtitle) {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(18), dp(24), dp(18), dp(28));
        scroll.addView(content);
        setContentView(scroll);

        TextView logo = text("✦ 大角君工具箱", 30, TEXT, true);
        logo.setGravity(Gravity.CENTER);
        content.addView(logo);

        TextView sub = text("Anime Repair Assistant", 13, BLUE, false);
        sub.setGravity(Gravity.CENTER);
        sub.setLetterSpacing(0.12f);
        content.addView(sub);

        TextView t = text(title, 24, TEXT, true);
        t.setPadding(0, dp(22), 0, dp(4));
        content.addView(t);

        TextView s = text(subtitle, 14, SUB, false);
        s.setPadding(0, 0, 0, dp(14));
        content.addView(s);
    }

    private void showHome() {
        base("二次元修机玩机助手", "手机端负责看教程、复制命令、理清流程；电脑端继续用大角君 BAT 执行刷机。");
        hero();
        card("修机模式", "卡开机、Recovery、Fastboot、9008 判断流程。", v -> showRepair());
        card("玩机模式", "Recovery、Magisk、vbmeta、A/B 槽位、Bootloader。", v -> showPlay());
        card("命令库", "常用 ADB / Fastboot 命令，一键复制。", v -> showCommands());
        card("资料说明", "驱动、固件、刷机前检查和风险提醒。", v -> showDocs());
        card("开源信息", "MIT 协议，适合二次开发和二次元主题改造。", v -> showOpenSource());
    }

    private void hero() {
        LinearLayout box = panel();
        TextView girl = text("◈ 电子猫娘修机中 ◈", 22, BLUE, true);
        girl.setGravity(Gravity.CENTER);
        box.addView(girl);
        TextView line = text("「先判断模式，再选流程；能不清数据，就别清数据。」", 15, SUB, false);
        line.setGravity(Gravity.CENTER);
        line.setPadding(0, dp(8), 0, 0);
        box.addView(line);
        content.addView(box);
    }

    private void showRepair() {
        base("修机模式", "按手机当前状态判断处理方式。");
        back();
        info("能开机，能连 ADB", "先备份资料，再重启 Recovery。必要时刷 OTA 或清数据。");
        info("卡开机，但能进 Recovery", "优先使用 Recovery Sideload 刷官方 OTA。刷完仍卡，再考虑清数据。");
        info("进不了系统，但能进 Fastboot", "用电脑端工具刷官方 boot / init_boot / vendor_boot / vbmeta。");
        info("电脑显示 9008 / EDL", "ADB/Fastboot 通常无效。需要 9008 驱动、官方线刷包、QFIL 或 MiFlash。");
    }

    private void showPlay() {
        base("玩机模式", "高级功能只做提示和命令复制，真正刷机仍建议在电脑端执行。");
        back();
        info("刷 Recovery / TWRP", "Fastboot 模式下刷 recovery.img，刷完建议直接重启到 Recovery。");
        command("刷 Recovery", "fastboot flash recovery recovery.img");
        info("Magisk patched boot", "先用 Magisk App 修补 boot.img 或 init_boot.img，再用电脑刷入。");
        command("刷 patched boot", "fastboot flash boot magisk_patched.img");
        command("刷 patched init_boot", "fastboot flash init_boot magisk_patched.img");
        info("vbmeta 禁用验证", "部分自定义镜像需要禁用验证，固件必须匹配。");
        command("刷 vbmeta", "fastboot --disable-verity --disable-verification flash vbmeta vbmeta.img");
        info("A/B 槽位", "OTA 后无法启动时，可以查看当前槽位并切换测试。");
        command("查看槽位", "fastboot getvar current-slot");
        command("切换到 a 槽", "fastboot --set-active=a");
        command("切换到 b 槽", "fastboot --set-active=b");
    }

    private void showCommands() {
        base("命令库", "点按钮复制命令，再到电脑端 CMD 使用。");
        back();
        command("查看 ADB 设备", "adb devices");
        command("重启到 Recovery", "adb reboot recovery");
        command("重启到 Fastboot", "adb reboot bootloader");
        command("Sideload 刷 OTA", "adb sideload update.zip");
        command("查看 Fastboot 设备", "fastboot devices");
        command("查看产品名", "fastboot getvar product");
        command("清 userdata", "fastboot erase userdata");
        command("重启系统", "fastboot reboot");
    }

    private void showDocs() {
        base("资料说明", "修机前先确认工具、驱动、固件和数据风险。");
        back();
        info("驱动", "Windows 需要 ADB/Fastboot 驱动。9008 需要 Qualcomm HS-USB QDLoader 驱动。");
        info("固件", "必须对应机型、区域版本和 Android 大版本。不同机型不能混刷。");
        info("数据", "fastboot erase userdata 会清空数据。能不清数据就不要清。");
        info("Bootloader", "解锁通常会清数据。锁回前必须确认完整官方系统，否则可能不开机。");
    }

    private void showOpenSource() {
        base("开源信息", "项目面向学习、修机记录和命令辅助，不内置危险自动化。");
        back();
        info("协议", "MIT License。你可以二次开发、改主题、改页面、改命令库。");
        info("项目结构", "原生 Java Android 项目，无第三方依赖，适合 Android Studio 打开。");
        info("建议开源仓库名", "DajiaojunAnimeToolbox");
        command("Git 初始化", "git init && git add . && git commit -m \"init anime toolbox\"");
    }

    private void back() {
        Button b = button("返回首页");
        b.setOnClickListener(v -> showHome());
        content.addView(b);
    }

    private void card(String title, String desc, View.OnClickListener l) {
        LinearLayout box = panel();
        TextView t = text(title, 19, TEXT, true);
        box.addView(t);
        TextView d = text(desc, 14, SUB, false);
        d.setPadding(0, dp(6), 0, dp(8));
        box.addView(d);
        Button b = button("进入");
        b.setOnClickListener(l);
        box.addView(b);
        content.addView(box);
    }

    private void info(String title, String body) {
        LinearLayout box = panel();
        box.addView(text(title, 18, BLUE, true));
        TextView b = text(body, 14, SUB, false);
        b.setPadding(0, dp(6), 0, 0);
        box.addView(b);
        content.addView(box);
    }

    private void command(String title, String cmd) {
        LinearLayout box = panel();
        box.addView(text(title, 17, PURPLE, true));
        TextView c = text(cmd, 13, TEXT, false);
        c.setTypeface(Typeface.MONOSPACE);
        c.setPadding(0, dp(8), 0, dp(10));
        box.addView(c);
        Button b = button("复制命令");
        b.setOnClickListener(v -> copy(cmd));
        box.addView(b);
        content.addView(box);
    }

    private LinearLayout panel() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(14), dp(16), dp(14));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(10), 0, dp(10));
        box.setLayoutParams(lp);
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(CARD);
        gd.setCornerRadius(dp(18));
        gd.setStroke(dp(1), Color.argb(110, 176, 132, 255));
        box.setBackground(gd);
        return box;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.rgb(10, 16, 32));
        b.setTextSize(14);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{BLUE, PURPLE});
        gd.setCornerRadius(dp(999));
        b.setBackground(gd);
        return b;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setLineSpacing(0, 1.08f);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    private void copy(String s) {
        ClipboardManager cm = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("大角君命令", s));
        Toast.makeText(this, "已复制命令", Toast.LENGTH_SHORT).show();
    }

    private int dp(int v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }
}

# 大角君工具箱 Anime Edition

二次元风格 Android 修机玩机助手。  
它不是手机端刷机器，而是一个开源的教程、命令库和流程辅助 App。

## 功能

- 修机模式：卡开机、Recovery、Fastboot、9008 判断
- 玩机模式：TWRP、Magisk patched boot、vbmeta、A/B 槽位说明
- 命令库：常用 ADB / Fastboot 命令一键复制
- 资料说明：驱动、固件、数据、Bootloader 风险提示
- 二次元霓虹卡片 UI
- 原生 Java Android，无第三方依赖

## 不能做什么

普通 APK 不能替代电脑端 ADB / Fastboot 工具，不能直接给另一台手机刷 Fastboot 分区。

推荐组合：

```text
手机端：大角君 Anime APK，看教程、复制命令
电脑端：大角君工具箱 BAT，执行 ADB / Fastboot
```

## 构建

用 Android Studio 打开本项目，等待 Gradle 同步后点击 Run。

命令行构建：

```bash
./gradlew assembleDebug
```

如果没有 Gradle Wrapper，可用 Android Studio 自动生成，或本机 Gradle：

```bash
gradle assembleDebug
```

## 开源协议

MIT License
